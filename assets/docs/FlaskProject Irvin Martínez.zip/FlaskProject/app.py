from flask import Flask, render_template, request, redirect, url_for, jsonify, session
import os
import json
from werkzeug.utils import secure_filename
from datetime import datetime
import hashlib

app = Flask(__name__)

# Configuraciones
app.config['SECRET_KEY'] = 'clave_secreta_para_admin_12345'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

# Crear carpeta de uploads si no existe
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Archivos de datos
NOTICIAS_FILE = 'noticias.json'
PASSWORD_FILE = 'admin_password.json'

# Contraseña por defecto (solo se usa si no existe el archivo)
DEFAULT_PASSWORD = 'admin123'


def cargar_contraseña():
    """Carga la contraseña desde el archivo JSON"""
    if os.path.exists(PASSWORD_FILE):
        with open(PASSWORD_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get('password', DEFAULT_PASSWORD)
    return DEFAULT_PASSWORD


def guardar_contraseña(nueva_contraseña):
    """Guarda la contraseña en el archivo JSON"""
    with open(PASSWORD_FILE, 'w', encoding='utf-8') as f:
        json.dump({'password': nueva_contraseña}, f, ensure_ascii=False, indent=2)


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def cargar_noticias():
    """Carga las noticias desde el archivo JSON"""
    if os.path.exists(NOTICIAS_FILE):
        with open(NOTICIAS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []


def guardar_noticias(noticias):
    """Guarda las noticias en el archivo JSON"""
    with open(NOTICIAS_FILE, 'w', encoding='utf-8') as f:
        json.dump(noticias, f, ensure_ascii=False, indent=2)


@app.context_processor
def inject_noticias():
    """Inyecta las noticias en todas las plantillas"""
    return dict(noticias_globales=cargar_noticias())


# Rutas principales
@app.route('/')
def inicio():
    return render_template('index.html')


@app.route('/servicios')
def servicios():
    return render_template('servicios.html')


@app.route('/productos')
def productos():
    return render_template('productos.html')


@app.route('/contactos')
def contactos():
    return render_template('contactos.html')


@app.route('/clientes')
def clientes():
    noticias = cargar_noticias()
    noticias.sort(key=lambda x: x.get('fecha', ''), reverse=True)
    return render_template('clientes.html', noticias=noticias)


# PANEL DE ADMINISTRACIÓN
@app.route('/ADMIN', methods=['GET', 'POST'])
def admin():
    error = None
    mensaje_exito = None
    password_actual = cargar_contraseña()

    # Verificar si ya está autenticado por sesión
    if session.get('admin_autenticado'):
        noticias = cargar_noticias()
        return render_template('admin.html', autenticado=True, noticias=noticias, mensaje_exito=mensaje_exito)

    if request.method == 'POST':
        # Verificar si es login normal o cambio de contraseña
        if 'password' in request.form and 'nueva_password' not in request.form:
            # Login normal
            password = request.form.get('password')
            if password == password_actual:
                session['admin_autenticado'] = True
                noticias = cargar_noticias()
                return render_template('admin.html', autenticado=True, noticias=noticias, mensaje_exito=mensaje_exito)
            else:
                error = 'Contraseña incorrecta'

    return render_template('admin.html', autenticado=False, error=error)


@app.route('/admin/cambiar_password', methods=['POST'])
def cambiar_password():
    """Cambia la contraseña del administrador"""
    if not session.get('admin_autenticado'):
        return jsonify({'error': 'No autorizado'}), 401

    password_actual = request.form.get('password_actual')
    nueva_password = request.form.get('nueva_password')
    confirmar_password = request.form.get('confirmar_password')

    # Validaciones
    if not password_actual or not nueva_password or not confirmar_password:
        return jsonify({'error': 'Todos los campos son obligatorios'}), 400

    if len(nueva_password) < 4:
        return jsonify({'error': 'La nueva contraseña debe tener al menos 4 caracteres'}), 400

    if nueva_password != confirmar_password:
        return jsonify({'error': 'Las contraseñas nuevas no coinciden'}), 400

    # Verificar contraseña actual
    password_guardada = cargar_contraseña()
    if password_actual != password_guardada:
        return jsonify({'error': 'Contraseña actual incorrecta'}), 400

    # Guardar nueva contraseña
    guardar_contraseña(nueva_password)

    return jsonify({'success': 'Contraseña cambiada exitosamente'}), 200


@app.route('/admin/logout')
def admin_logout():
    """Cerrar sesión del administrador"""
    session.pop('admin_autenticado', None)
    return redirect(url_for('admin'))


@app.route('/admin/agregar', methods=['POST'])
def agregar_noticia():
    if not session.get('admin_autenticado'):
        return jsonify({'error': 'No autorizado'}), 401

    titulo = request.form.get('titulo')
    resumen = request.form.get('resumen')
    enlace = request.form.get('enlace')
    imagen_url = request.form.get('imagen_url')

    if not titulo or not resumen or not enlace:
        return jsonify({'error': 'Faltan campos obligatorios'}), 400

    if 'imagen' in request.files:
        file = request.files['imagen']
        if file and allowed_file(file.filename):
            filename = secure_filename(f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            imagen_url = url_for('static', filename=f'uploads/{filename}')

    if not imagen_url:
        imagen_url = 'https://placehold.co/600x400/1a1a2e/ffffff?text=Sin+Imagen'

    nueva_noticia = {
        'id': datetime.now().strftime('%Y%m%d%H%M%S'),
        'titulo': titulo,
        'resumen': resumen,
        'enlace': enlace,
        'imagen_url': imagen_url,
        'fecha': datetime.now().isoformat()
    }

    noticias = cargar_noticias()
    noticias.insert(0, nueva_noticia)
    guardar_noticias(noticias)

    return redirect(url_for('admin'))


@app.route('/admin/eliminar/<id_noticia>')
def eliminar_noticia(id_noticia):
    if not session.get('admin_autenticado'):
        return redirect(url_for('admin'))

    noticias = cargar_noticias()
    noticias = [n for n in noticias if n.get('id') != id_noticia]
    guardar_noticias(noticias)

    return redirect(url_for('admin'))


@app.route('/admin/editar/<id_noticia>', methods=['POST'])
def editar_noticia(id_noticia):
    if not session.get('admin_autenticado'):
        return jsonify({'error': 'No autorizado'}), 401

    titulo = request.form.get('titulo')
    resumen = request.form.get('resumen')
    enlace = request.form.get('enlace')

    noticias = cargar_noticias()

    for i, noticia in enumerate(noticias):
        if noticia.get('id') == id_noticia:
            noticias[i]['titulo'] = titulo
            noticias[i]['resumen'] = resumen
            noticias[i]['enlace'] = enlace

            if 'imagen' in request.files:
                file = request.files['imagen']
                if file and allowed_file(file.filename):
                    filename = secure_filename(f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(filepath)
                    noticias[i]['imagen_url'] = url_for('static', filename=f'uploads/{filename}')
            break

    guardar_noticias(noticias)
    return redirect(url_for('admin'))


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)